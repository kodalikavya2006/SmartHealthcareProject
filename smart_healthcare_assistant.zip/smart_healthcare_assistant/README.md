# CareNest — Smart Healthcare Assistant

This project converts the supplied Travel Guide frontend into a healthcare assistant demo. It includes a Flask API, a chat interface, an appointment request organizer, and a medication schedule organizer.

## Features
- General health Q&A with conservative, rule-based starter responses.
- Safety response for several emergency phrases.
- Add/list/remove appointment requests.
- Add/list/remove medication reminder details.
- Responsive dashboard UI.

## Run on Windows
1. Install Python 3.10 or newer.
2. Open PowerShell in the project folder.
3. Create and activate a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
4. Install dependencies:
   ```powershell
   pip install flask flask-cors
   ```
5. Start the app from the project root:
   ```powershell
   python Backend/app.py
   ```
6. Open http://127.0.0.1:5000 in your browser.

## Important implementation notes
- The assistant currently uses simple rule-based sample responses. It is not connected to MERF.ai or a medical knowledge base yet.
- To connect MERF.ai, replace `assistant_reply()` in `Backend/app.py` with a server-side request to your MERF.ai workflow/API. Keep API keys in environment variables; do not put secrets in frontend JavaScript.
- Appointment requests are not sent to a real clinic and are not confirmed bookings.
- Medication reminder details are not timed notifications. Add a trusted scheduler/notification service if needed.
- Storage is in-memory for this demo and resets when the Flask server restarts. Use a properly secured database and authentication before handling real users or health information.
- The assistant is not a doctor. Do not use it for diagnosis, prescribing, or emergencies.
